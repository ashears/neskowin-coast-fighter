# 2D Fighter Framework

A dependency-free TypeScript combat simulation for two-player 2D fighters. The package includes health rounds, platform stocks, typed custom rules, snapshot restore, and input recordings. Use it from a browser renderer or a headless match server.

```ts
import { Button, createMatch, healthRules } from '@ashears/2d-fighter-framework';
import type { FighterDefinition, MatchDefinition } from '@ashears/2d-fighter-framework';

const jab = {
  name: 'Jab', startup: 4, active: 3, recovery: 10,
  actions: [{
    type: 'hitbox' as const, frame: 4, duration: 3,
    box: { x: 10, y: -38, width: 30, height: 24 },
    impact: { damage: 9, guardDamage: 5, hitstun: 12, knockback: { x: 3, y: 0 } },
  }],
};

const fighter: FighterDefinition = {
  id: 'example', name: 'Example', maxHealth: 100, maxGuard: 50, guardRegen: 0.35,
  walkSpeed: 4, jumpSpeed: 13, airJumps: 1, hurtbox: { x: -12, y: -50, width: 24, height: 50 },
  moves: { light: jab, heavy: jab, special: jab },
};

const definition: MatchDefinition = {
  fighters: [fighter, fighter], seed: 42, timeLimit: 60 * 60,
  stage: {
    id: 'yard', gravity: 0.65, fallSpeed: 15,
    walls: { left: 0, right: 480 },
    spawns: [{ x: 160, y: 300 }, { x: 320, y: 300 }],
    surfaces: [{ id: 'floor', x: 0, y: 300, width: 480, oneWay: false }],
  },
};

const match = createMatch(definition, healthRules);
const { snapshot, events } = match.step([Button.Right | Button.Light, 0]);
```

Call `step` once per simulation tick at 60 Hz. Send a bitmask of held buttons for each seat. The engine detects fresh attack and jump presses, so send a release before pressing the same action again. Snapshots are frozen. Use `serializeSnapshot` to save one and pass the parsed value as the third argument to `createMatch` to resume. Pass the original definitions and rule version when restoring or playing back a recording. Snapshot and recording format v2 start with release 0.2.0. Use release 0.1.0 for v1 data.

Positions are measured at the fighter's feet. Positive X is right and positive Y is down. Velocities use world units per tick. Hitboxes are defined relative to the fighter or projectile while facing right. The engine mirrors their offsets automatically. Move frame numbers start at zero.

## Charge, landing, and persistent attacks

- Set `chargeTicks` to hold a move on frame zero until the player releases its attack button or reaches the limit. Set `chargedVelocity` on an impulse or projectile to interpolate from the ordinary velocity at tap strength to that velocity at full charge. A `cooldownTicks` value limits how soon that move can start again without locking the other buttons.
- Set `onLanding` on a hitbox to fire it only on the first landing during its active window. An upward frame-zero impulse paired with a landing hitbox makes a jumping slam.
- A hitbox can schedule one `followup` impact at a fixed delay after an unblocked hit. The attack has to stay active until the follow-up frame. To author a grab, use an `unblockable` opening impact with zero damage and enough hitstun to cover the delay, then put the slam damage on the follow-up.
- Projectiles can settle onto stage surfaces and fall off edges with `motion: { type: 'ground' }`, or circle the target's position at spawn with `motion: { type: 'orbit', radius, period }`. Set `trackX` to the fraction of the horizontal gap that the orbit center closes each tick. Use `armTicks` for delayed contact, `rehitTicks` to keep the projectile alive after contact, and `knockbackFromContact` to push away from either side. A projectile action can supply weighted `variants` to choose from the match seed. Use `getProjectileDefinition` to resolve the active variant and read its optional `appearance` for rendering.

Set `previewVariant` on a projectile action with weighted variants to choose its item as soon as the attack starts. During windup, look up the chosen index in `actor.move.projectileVariants` by action index.

## Air attacks and stock tuning

- Add `airLight`, `airHeavy`, or `airSpecial` to select a different move when that attack starts airborne. Add `downLight` for a grounded Down + Light attack.
- Add an airborne `recovery` move and send `RECOVERY_INPUT` to start it once per airtime. With a horizontal direction held, its impulse points that way. Use `airControl` to set how much steering the player retains each tick, and `landingLag` to end the active move with a set number of locked ticks when the fighter lands.
- Set `stockWeight` on a fighter to change how far they launch in percent rules. Set `stock` on an impact to override its guard damage, hitstun, and knockback in stock matches. The optional `scaling` controls how strongly accumulated percent multiplies the launch.

These options keep snapshot and recording format v2. Use matching match definitions for both clients and replay playback.

### Authoring platform stages

World coordinates use pixels, with positive y pointing down. A fighter's position is its foot. Each surface describes a top edge from `(x, y)` to `(x + width, endY ?? y)`. Join endpoints at the same coordinates for a continuous bank. Leave horizontal space between pieces for a gap. Fighters can rise through top edges. Set `oneWay` on platforms that also allow Down + Jump to drop through. Use walls for enclosed duels, or a blast-zone rectangle and stock rules for ring-outs.

```ts
import { surfaceSpawn, type StageDefinition, type Surface } from '@ashears/2d-fighter-framework';

const surfaces: Surface[] = [
  { id: 'bank', x: 120, y: 430, endY: 380, width: 200, oneWay: false, material: 'rock' },
  { id: 'deck', x: 320, y: 380, width: 440, oneWay: false, material: 'timber' },
  { id: 'shelf', x: 440, y: 275, width: 180, oneWay: true, material: 'timber' },
];
const stage: StageDefinition = {
  id: 'harbor', gravity: 0.67, fallSpeed: 19, surfaces,
  spawns: [surfaceSpawn(surfaces, 'bank', 150), surfaceSpawn(surfaces, 'deck', 280)],
  blastZone: { x: -40, y: -100, width: 1040, height: 740 },
};
```

Material names belong to the game renderer. Draw the terrain from the same surface endpoints used by the simulation and arena picker. Use `surfaceHeight` for positioning props and `landingSurface` for landing previews. To tune aerial handling per fighter, set `airDrift` (fraction of target speed reached each free-air tick) and `fastFallSpeed` (downward velocity on a fresh Down press while descending). Aerial attacks retain their own `airControl`.

## Browser menus

Import `@ashears/2d-fighter-framework/browser-ui.css` alongside the existing picker styles. For a wide arena screen, use `fighter-setup-panel` on the setup panel and `fighter-arena-layout` on the grid. Place the picker preview beside a `fighter-arena-rail` that holds the choices, rules and actions. Pass the choices element as the optional final argument to `createArenaSelect` to mount its buttons in the rail.

The `@ashears/2d-fighter-framework/browser-ui` entry exports `matchFormats` and `formatLives` for player-facing rules text. It also exports `createDisclosure(trigger, content)` for a button that shows and hides content, and `createCampaignRoute(list, bouts, onSelect)` for an ordered bracket. Call the route’s `update(selected, statusOf)` after progress or selection changes. The game supplies the matchup preview and decides who fights each bout.

Use `fighter-results` on the result section and `fighter-result-actions` on its button group. Show the outcome and score in this section, and focus the result heading when the match ends. The Aftershift demo uses the shared arena and result layouts.
